import numpy as np


# =============================== Math Func ===============================


def relu(x):
    return np.maximum(x, 0)


def d_relu(x):
    return x > 0


def softMax(x):
    return np.array(np.exp(x) / np.sum(np.exp(x), axis=1))


# =============================== Matrix Func ===============================


def OneHot(length, width, y):
    # OneHot encoding
    y = np.array(y).ravel()
    r = np.zeros((length, width))
    for i in range(length):
        r[i][int(y[i])] = 1.0
    return r


def AddBias(x):
    x = np.matrix(x)
    return np.c_[np.ones((x.shape[0], 1)), x]


def RemoveBias(x):
    return np.matrix(x)[:, 1:]


# =============================== Network ===============================


class Network:
    def Init(self, unitNum):
        self.unitNum = unitNum
        self.layerNum = len(unitNum)
        self.w = [0]
        self.Z = [0]
        self.A = [0]
        self.ClrTempResult()

    def backProp(self, d_lossFunc):
        self.dZ[-1] = d_lossFunc()
        dw = self.A[-2].T * self.dZ[-1]
        db = np.sum(self.dZ[-1], axis=0)
        self.dw[-1] = np.r_[db, dw]
        for i in reversed(range(1, self.layerNum - 1)):
            self.dA[i] = RemoveBias(self.dZ[i + 1] * self.w[i + 1].T)
            self.dZ[i] = np.multiply(d_relu(self.Z[i]), self.dA[i])
            dw = self.A[i - 1].T * self.dZ[i]
            db = np.sum(self.dZ[i], axis=0)
            self.dw[i] = np.r_[db, dw]
        self.dA[0] = RemoveBias(self.dZ[1] * self.w[1].T)
        self.dZ[0] = self.dA[0]

    def forwardProp(self):
        for i in range(1, self.layerNum - 1):
            self.Z.append(AddBias(self.A[-1]) * self.w[i])
            self.A.append(relu(self.Z[-1]))
        self.Z.append(AddBias(self.A[-1]) * self.w[-1])
        self.A.append(softMax(self.Z[-1]))

    def ClrTempResult(self):
        self.Z = self.Z[0:1]
        self.A = self.A[0:1]
        self.dw = list(np.repeat(1, self.layerNum, axis=0))
        self.dZ = list(np.repeat(1, self.layerNum, axis=0))
        self.dA = list(np.repeat(1, self.layerNum, axis=0))

    def predict(self, X):
        self.ClrTempResult()
        self.Z[0] = np.matrix(X)
        self.A[0] = np.matrix(X)
        self.forwardProp()
        return np.array(self.A[-1])

    def d_crossEntPert(self):
        mat = np.matrix(self.A[-1] - self.y)
        if np.argmax(np.array(self.y).ravel()) != np.argmax(np.array(self.A[-1]).ravel()):
            for i in range(10):
                if i != np.argmax(np.array(self.y).ravel()) and i != np.argmax(np.array(self.A[-1]).ravel()):
                    mat[0, i] = 0
        return mat

    def LoadParameters(self, fileName):
        f = open(fileName, "rb")
        wt = np.frombuffer(f.read(), np.float64)
        f.close()
        for i in range(1, len(self.unitNum)):
            data = wt[: (self.unitNum[i - 1] + 1) * self.unitNum[i]]
            shape = (self.unitNum[i - 1] + 1, self.unitNum[i])
            self.w.append(np.matrix(data).reshape(shape))
            wt = wt[(self.unitNum[i - 1] + 1) * self.unitNum[i]:]


# =============================== Fool ===============================


class Fool:
    def __init__(self, myNetwork):
        self.Network = myNetwork

    def GetGrad(self, X):
        pred = self.Network.predict(X)
        self.Network.backProp(self.Network.d_crossEntPert)
        return self.Network.dA[0], pred.ravel()

    def Fool(self, X, y, tar, foolRate=0.5, maxIter=500, step=0.05, minGrad=0.05, maxGrad=10,
             constrain=10, stuckRandL2=1, initRandL2=1):
        rand = np.matrix(np.random.randn(1, 784))
        pert = np.zeros((1, 784)) + initRandL2 * rand / np.linalg.norm(rand)
        loss = []
        L2Rec = []
        cnt = 0
        stuckCnt = 0
        stuckJudgeCnt = 0
        success = False
        self.Network.predict(X + pert)
        print("init: " + str(y) + " prob: " +
              str(self.Network.A[-1].ravel()[y]))
        self.Network.y = OneHot(
            1, self.Network.unitNum[-1], y) if tar == -1 else OneHot(1, self.Network.unitNum[-1], tar)
        while(True):
            print("\rcnt: " + str(cnt) + "  stuck: " + str(stuckCnt), end='')
            grad, pred = self.GetGrad(X + pert)
            loss.append(np.linalg.norm(self.Network.A[-1]) if tar == -1 else
                        -np.sum(np.array(self.Network.y) * np.log(self.Network.A[-1])
                        + np.array(1 - self.Network.y) * np.log(1 - self.Network.A[-1])))
            if ((self.Network.A[-1].ravel()[y] < foolRate if tar == -1 else self.Network.A[-1].ravel()[tar] > foolRate)
                    and stuckJudgeCnt > 5):
                print("\n⭕ OK:      " + str(np.argmax(pred)) + "    " +
                      str(self.Network.A[-1].ravel()[np.argmax(pred)]) + "\n")
                success = True
                break
            if np.linalg.norm(pert):
                para = max((np.linalg.norm(pert) - constrain) ** 3, 0)
                grad -= np.sum(np.array(pert) * np.array(grad)) * \
                    (pert / np.linalg.norm(pert)) * para
            L2 = np.linalg.norm(grad)
            L2Rec.append(np.array(L2).ravel())
            if L2 > maxGrad:
                grad *= maxGrad / L2
            if L2 < minGrad:
                if L2 == 0:
                    print("\nERR: grad is zero")
                    break
                grad *= minGrad / L2
            pert -= grad * step
            cnt += 1
            if cnt == maxIter - 1:
                print("\n❌ nope:   " + str(y if tar == -1 else tar) + "      " +
                      str(self.Network.A[-1].ravel()[y if tar == -1 else tar]) + "\n")
                break
            if cnt > 1 and abs(loss[-1] - loss[-2]) < 0.1:
                stuckJudgeCnt += 1
                if stuckJudgeCnt > 10:
                    rand = np.matrix(np.random.randn(
                        pert.shape[0], pert.shape[1]))
                    pert += rand / np.linalg.norm(rand) * stuckRandL2
                    stuckJudgeCnt = 0
                    stuckCnt += 1
        return success, pert, loss, L2Rec